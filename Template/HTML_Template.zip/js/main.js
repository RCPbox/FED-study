/*! main.js © yamoo9.net, 2015 */
(function(global, $, undefined){
	'use strict';

})(window, window.jQuery);